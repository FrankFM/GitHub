package Java_Project;

/**
 * Created by f_mol on 01-12-2016.
 */
public class SolvedException extends Exception
{

}