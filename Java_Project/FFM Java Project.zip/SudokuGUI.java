package Java_Project;

/**
 * Created by f_mol on 15-12-2016.
 */

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class SudokuGUI extends JPanel implements ActionListener
{
    public static void main (String[] args)
    {
        JFrame window = new JFrame("Sudoku Solver");
        SudokuGUI content = new SudokuGUI();
        window.setSize(1000, 1000);
        window.setContentPane(content);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);

    }
    //We start out with defining the Buttons to be used and shown in the Sudoku GUI
    private JButton Save; //A button which will give the opportunity to solve the Sudoku result
    private JButton Clear; //A button which will clear the Sudoku Field
    private JButton Load; //A button which will load any given Sudoku input text file for solving
    private JButton Solve; //A button which will solve the Sudoku when pressed


    public SudokuGUI()
    {
        //We start out with defining variables which will be used in creating the Sudoku board
        int field_row = Field.SIZE;
        int field_col = Field.SIZE;
        JTextField all_fields[][] = new JTextField[field_row][field_col];


        JPanel grid = new JPanel(new GridLayout(field_row, field_col, 2, 2)); //A panel that will hold the Sudoku field
        grid.setVisible(true);
        grid.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        //We define a nested for-loop to create the Sudoku field with JTextFields inside
           for (int i = 0; i < field_row; i++){
                for (int j = 0; j < field_col; j++){
                    all_fields[i][j] = new JTextField();
                    grid.add(all_fields[i][j]);
                }
            }


        JPanel buttonpanel = new JPanel(); //A panel that will hold the buttons
        buttonpanel.setLayout(new GridLayout(1,4,0,0));
        buttonpanel.setBackground(Color.LIGHT_GRAY);
        buttonpanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));


        JButton Save = new JButton("Save");
        //Save.addActionListener(new ActionListener(); //anonyme klasser til knapperne

        JButton Clear = new JButton("Clear");
        //Clear.addActionListener(this);

        JButton Load = new JButton("Load");
        Load.addActionListener(this);       //JFileChooser  kobles p� denne knap!!

        JButton Solve = new JButton("Solve!");
        //Solve.addActionListener(this);

        JPanel mainpanel = new JPanel(new BorderLayout()); //A panel that will hold the buttonpanel
        mainpanel.setVisible(true);
        mainpanel.add(buttonpanel, BorderLayout.SOUTH);


        setBorder(BorderFactory.createEmptyBorder(2,2,2,2));
        setLayout(new GridLayout(2,2,0,0));
        buttonpanel.add(Save);
        buttonpanel.add(Clear);
        buttonpanel.add(Load);
        buttonpanel.add(Solve);
        add(grid);
        add(mainpanel);

    }
    //This function will handle the Save button,

        JFileChooser choosefile = new JFileChooser();
        //int returnVal = choosefile.showSaveDialog(this);
        BufferedWriter savefile = null;
        File savetext;

        //file = choosefile.getSelectedFile();
        //savefile = new BufferedWriter(new FileWriter(file));
        //for(int row = 0; row < Field.SIZE; row++){
          //  for(int col = 0; col < Field.SIZE; col++){
          ///      savefile.write();






    //This function will handle the Load button,

        JFileChooser loadfile = new JFileChooser();
        int returnVal = loadfile.showOpenDialog(this);

        File file = loadfile.getSelectedFile();








    public void actionPerformed (ActionEvent e)
    {
        //The action event for the "Load" button

        if (e.getSource() == Load){


            if (returnVal == JFileChooser.CANCEL_OPTION){
                System.exit(0);

            }



        }

    }

}
